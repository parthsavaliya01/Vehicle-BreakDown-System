<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Vehicle Break Down System: Dashboard</title>
    </head>

    <a class="navbar-brand" href="user/dashboard.php">Dashboard</a>
</html>